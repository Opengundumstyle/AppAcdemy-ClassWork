# require 'rspec'
# require 'first_tdd'

# describe Array
# describe "#remove_dups" do 
#     it "removes duplicates from an array" do 
#         expect()
#     end
# end





